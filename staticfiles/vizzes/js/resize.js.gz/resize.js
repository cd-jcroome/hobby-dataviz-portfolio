function resize() {
    const height = window.innerHeight
    const width = window.innerWidth
};